# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Stockcontrol::Application.config.secret_token = '1f5bbeefa9a6c3b20f2adf738d2db8121db72536b3bbe07eb773d4a59230d415beeda7969423ac37562990c961b0a4ebfb018a202a04196b23a8e5f90d09b47c'
