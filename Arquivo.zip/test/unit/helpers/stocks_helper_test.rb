require 'test_helper'

class StocksHelperTest < ActionView::TestCase
end
